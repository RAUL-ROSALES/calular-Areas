﻿using System;

namespace Areas
{
    class Program
    {
        static void Main(string[] args)
        {
            Principal p = new Principal();
            p.Menu();
            Console.ReadKey();
        }
    }
}
